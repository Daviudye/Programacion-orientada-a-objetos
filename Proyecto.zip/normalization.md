# Normalización hasta 3FN

Se normalizó la base de datos para que cada entidad tenga su propia tabla y no haya datos repetidos.

## Autor
- ID (PK)
- Nombre
- Nacionalidad

## Libro
- ID (PK)
- Título
- ISBN
- Año
- ID_Autor (FK)

## Estudiante
- ID (PK)
- Nombre
- Grado

## Prestamo
- ID (PK)
- ID_Libro (FK)
- ID_Estudiante (FK)
- Fecha_préstamo
- Fecha_devolución

**Notas:**  
- 1FN: Cada campo tiene un solo valor.  
- 2FN: Todas las columnas dependen completamente de la PK.  
- 3FN: No hay dependencias transitivas, por ejemplo el nombre del autor no se repite en libros.
