#include "biblioteca.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

// Cargar datos de los archivos
void BibliotecaDB::cargarDatos() {
    ifstream fileL("data/libros.txt");
    string line;
    while (getline(fileL, line)) {
        stringstream ss(line);
        Libro l;
        string temp;
        getline(ss, temp, ','); l.id = stoi(temp);
        getline(ss, l.titulo, ',');
        getline(ss, l.isbn, ',');
        getline(ss, temp, ','); l.ano = stoi(temp);
        getline(ss, temp, ','); l.id_autor = stoi(temp);
        libros.push_back(l);
    }
    fileL.close();

    ifstream fileA("data/autores.txt");
    while (getline(fileA, line)) {
        stringstream ss(line);
        Autor a;
        string temp;
        getline(ss, temp, ','); a.id = stoi(temp);
        getline(ss, a.nombre, ',');
        getline(ss, a.nacionalidad, ',');
        autores.push_back(a);
    }
    fileA.close();

    ifstream fileE("data/estudiantes.txt");
    while (getline(fileE, line)) {
        stringstream ss(line);
        Estudiante e;
        string temp;
        getline(ss, temp, ','); e.id = stoi(temp);
        getline(ss, e.nombre, ',');
        getline(ss, e.grado, ',');
        estudiantes.push_back(e);
    }
    fileE.close();

    ifstream fileP("data/prestamos.txt");
    while (getline(fileP, line)) {
        stringstream ss(line);
        Prestamo p;
        string temp;
        getline(ss, temp, ','); p.id = stoi(temp);
        getline(ss, temp, ','); p.id_libro = stoi(temp);
        getline(ss, temp, ','); p.id_estudiante = stoi(temp);
        getline(ss, p.fecha_prestamo, ',');
        getline(ss, p.fecha_devolucion, ',');
        prestamos.push_back(p);
    }
    fileP.close();
}

// Guardar datos en archivos
void BibliotecaDB::guardarDatos() {
    ofstream fileL("data/libros.txt");
    for (auto &l : libros) {
        fileL << l.id << "," << l.titulo << "," << l.isbn << "," << l.ano << "," << l.id_autor << endl;
    }
    fileL.close();

    ofstream fileA("data/autores.txt");
    for (auto &a : autores) {
        fileA << a.id << "," << a.nombre << "," << a.nacionalidad << endl;
    }
    fileA.close();

    ofstream fileE("data/estudiantes.txt");
    for (auto &e : estudiantes) {
        fileE << e.id << "," << e.nombre << "," << e.grado << endl;
    }
    fileE.close();

    ofstream fileP("data/prestamos.txt");
    for (auto &p : prestamos) {
        fileP << p.id << "," << p.id_libro << "," << p.id_estudiante << "," << p.fecha_prestamo << "," << p.fecha_devolucion << endl;
    }
    fileP.close();
}

// CRUD básico
void BibliotecaDB::agregarLibro(Libro l) { libros.push_back(l); }
void BibliotecaDB::listarLibros() { for (auto &l : libros) cout << l.id << " - " << l.titulo << " (" << l.ano << ")" << endl; }
void BibliotecaDB::agregarAutor(Autor a) { autores.push_back(a); }
void BibliotecaDB::listarAutores() { for (auto &a : autores) cout << a.id << " - " << a.nombre << endl; }
void BibliotecaDB::agregarEstudiante(Estudiante e) { estudiantes.push_back(e); }
void BibliotecaDB::listarEstudiantes() { for (auto &e : estudiantes) cout << e.id << " - " << e.nombre << " (" << e.grado << ")" << endl; }
void BibliotecaDB::agregarPrestamo(Prestamo p) { prestamos.push_back(p); }
void BibliotecaDB::listarPrestamos() { for (auto &p : prestamos) cout << p.id << " - Libro:" << p.id_libro << " Estudiante:" << p.id_estudiante << " Prestado:" << p.fecha_prestamo << endl; }

// Consultas
void BibliotecaDB::librosPorEstudiante(int idEstudiante) {
    cout << "Libros prestados por estudiante " << idEstudiante << ":" << endl;
    for (auto &p : prestamos) {
        if (p.id_estudiante == idEstudiante) {
            for (auto &l : libros) {
                if (l.id == p.id_libro) cout << l.titulo << endl;
            }
        }
    }
}

void BibliotecaDB::autorConMasLibros() {
    int max = 0; int idMax = -1;
    for (auto &a : autores) {
        int count = 0;
        for (auto &l : libros) if (l.id_autor == a.id) count++;
        if (count > max) { max = count; idMax = a.id; }
    }
    for (auto &a : autores) if (a.id == idMax) cout << "Autor con más libros: " << a.nombre << " (" << max << ")" << endl;
}
