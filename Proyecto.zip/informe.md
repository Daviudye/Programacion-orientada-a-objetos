# Informe final

En este proyecto aprendí a normalizar una base de datos hasta la tercera forma normal para evitar duplicados y dependencias innecesarias. También comprendí cómo usar structs y vectores en C++ para simular tablas en memoria, y cómo guardar los datos en archivos de texto para tener persistencia.  

Me ayudó a entender la relación entre las entidades (libros, autores, estudiantes, préstamos) y cómo implementar consultas simples para obtener información específica, como qué libros tiene un estudiante o qué autor tiene más libros.  

Este proyecto me permitió combinar teoría de bases de datos con programación práctica y sentó las bases para manejar bases de datos más complejas en el futuro.
