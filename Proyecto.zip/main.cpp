#include "biblioteca.h"
#include <iostream>
using namespace std;

int main() {
    BibliotecaDB db;
    db.cargarDatos();

    int opcion;
    while (true) {
        cout << "1. Agregar Libro\n2. Listar Libros\n3. Agregar Autor\n4. Listar Autores\n5. Agregar Estudiante\n6. Listar Estudiantes\n7. Agregar Prestamo\n8. Listar Prestamos\n9. Libros por Estudiante\n10. Autor con mas libros\n0. Salir\n";
        cin >> opcion;

        if (opcion == 1) {
            Libro l; cout << "ID: "; cin >> l.id; cin.ignore();
            cout << "Titulo: "; getline(cin, l.titulo);
            cout << "ISBN: "; getline(cin, l.isbn);
            cout << "Ano: "; cin >> l.ano;
            cout << "ID Autor: "; cin >> l.id_autor;
            db.agregarLibro(l);
        } else if (opcion == 2) db.listarLibros();
        else if (opcion == 3) {
            Autor a; cout << "ID: "; cin >> a.id; cin.ignore();
            cout << "Nombre: "; getline(cin, a.nombre);
            cout << "Nacionalidad: "; getline(cin, a.nacionalidad);
            db.agregarAutor(a);
        } else if (opcion == 4) db.listarAutores();
        else if (opcion == 5) {
            Estudiante e; cout << "ID: "; cin >> e.id; cin.ignore();
            cout << "Nombre: "; getline(cin, e.nombre);
            cout << "Grado: "; getline(cin, e.grado);
            db.agregarEstudiante(e);
        } else if (opcion == 6) db.listarEstudiantes();
        else if (opcion == 7) {
            Prestamo p; cout << "ID: "; cin >> p.id;
            cout << "ID Libro: "; cin >> p.id_libro;
            cout << "ID Estudiante: "; cin >> p.id_estudiante; cin.ignore();
            cout << "Fecha Prestamo: "; getline(cin, p.fecha_prestamo);
            cout << "Fecha Devolucion: "; getline(cin, p.fecha_devolucion);
            db.agregarPrestamo(p);
        } else if (opcion == 8) db.listarPrestamos();
        else if (opcion == 9) { int id; cout << "ID Estudiante: "; cin >> id; db.librosPorEstudiante(id); }
        else if (opcion == 10) db.autorConMasLibros();
        else if (opcion == 0) { db.guardarDatos(); break; }
    }
    return 0;
}
