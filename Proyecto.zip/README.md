# Proyecto Biblioteca Escolar

Sistema en C++ con CRUD completo para libros, autores, estudiantes y préstamos.

## Compilar
```bash
g++ main.cpp biblioteca.cpp -o biblioteca
```

## Ejecutar
```bash
./biblioteca
```

Los datos se guardan en la carpeta `data/`.
