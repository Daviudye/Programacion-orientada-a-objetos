#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include <string>
#include <vector>
using namespace std;

struct Libro {
    int id;
    string titulo;
    string isbn;
    int ano;
    int id_autor;
};

struct Autor {
    int id;
    string nombre;
    string nacionalidad;
};

struct Estudiante {
    int id;
    string nombre;
    string grado;
};

struct Prestamo {
    int id;
    int id_libro;
    int id_estudiante;
    string fecha_prestamo;
    string fecha_devolucion;
};

class BibliotecaDB {
public:
    vector<Libro> libros;
    vector<Autor> autores;
    vector<Estudiante> estudiantes;
    vector<Prestamo> prestamos;

    void cargarDatos();
    void guardarDatos();

    void agregarLibro(Libro l);
    void listarLibros();
    void agregarAutor(Autor a);
    void listarAutores();
    void agregarEstudiante(Estudiante e);
    void listarEstudiantes();
    void agregarPrestamo(Prestamo p);
    void listarPrestamos();

    void librosPorEstudiante(int idEstudiante);
    void autorConMasLibros();
};

#endif
